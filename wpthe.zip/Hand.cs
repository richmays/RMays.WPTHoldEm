using System;
using System.Text;

public class Hand
{
    private const byte MAX_CARDS = 7;
    private int[] hand;
    private byte iCardsInHand;

    public Hand()
    {
        hand = new int[MAX_CARDS];
        Reset();
    }

    public void Reset()
    {
        iCardsInHand = 0;
        for (int i = 0; i < MAX_CARDS; i++)
        {
            hand[i] = 0;
        }
    }

    public void AddCard(int card)
    {
        if (iCardsInHand < MAX_CARDS)
        {
            hand[iCardsInHand] = card;
            iCardsInHand++;
        }
    }

    /*
    public void RemoveCard(int card)
    {
        if (iCardsInHand > 0)
        {
            iCardsInHand--;
        }
    }
    */

    /*
    public static string GetHandValueText( string handValue )
    {
        Card c1 = new Card();
        Card c2 = new Card();
        Card c3 = new Card();
        Card c4 = new Card();
        Card c5 = new Card();

        if (handValue.Length > 1)
        {
            c1.SetFromStr(handValue.Substring(1, 2));
            if (handValue.Length > 3)
            {
                c2.SetFromStr(handValue.Substring(3, 2));
                if (handValue.Length > 5)
                {
                    c3.SetFromStr(handValue.Substring(5, 2));
                    if (handValue.Length > 7)
                    {
                        c4.SetFromStr(handValue.Substring(7, 2));
                        if (handValue.Length > 9)
                        {
                            c5.SetFromStr(handValue.Substring(9, 2));
                        }
                    }
                }
            }
        }

        switch ((char)handValue[0])
        {
            case '9':
                if (c1.Rank() == 'A')
                {
                    return "Royal Flush";
                }
                else
                {
                    return "Straight Flush, " + c1.RankNameSingular() + " high";
                }
            case '8':
                return "Four of a Kind, " + c1.RankNamePlural() + " (kicker " + c2.RankNameSingular() + ")";
            case '7':
                return "Full House, " + c1.RankNamePlural() + " full of " + c2.RankNamePlural();
            case '6':
                return "Flush, " + c1.RankNameSingular() + " high (kickers " + c2.RankNameSingular() + ", " + c3.RankNameSingular() + ", " + c4.RankNameSingular() + ", and " + c5.RankNameSingular() + ")";
            case '5':
                return "Straight, " + c1.RankNameSingular() + " high";
            case '4':
                return "Three of a Kind, " + c1.RankNamePlural() + " (kickers " + c2.RankNameSingular() + " and " + c3.RankNameSingular() + ")";
            case '3':
                return "Two Pair, " + c1.RankNamePlural() + " and " + c2.RankNamePlural() + " (kicker " + c3.RankNameSingular() + ")";
            case '2':
                return "Pair, " + c1.RankNamePlural() + " (kickers " + c2.RankNameSingular() + ", " + c3.RankNameSingular() + ", and " + c4.RankNameSingular() + ")";
            case '1':
                return "High Card, " + c1.RankNameSingular() + " (kickers " + c2.RankNameSingular() + ", " + c3.RankNameSingular() + ", " + c4.RankNameSingular() + ", and " + c5.RankNameSingular() + ")";
            default:
                return "Unknown! (" + handValue + ")";
        }
    }
    */

    public short eval_5cards(int c1, int c2, int c3, int c4, int c5)
    {
        int q;
        short s;

        q = (c1 | c2 | c3 | c4 | c5) >> 16;

        /* check for Flushes and StraightFlushes
        */
        if ((c1 & c2 & c3 & c4 & c5 & 0xF000) > 0)
            return (Global.flushes[q]);

        /* check for Straights and HighCard hands
        */
        s = Global.unique5[q];
        if (s > 0)
        {
            return (s);
        }

        /* let's do it the hard way
        */
        q = (c1 & 0xFF) * (c2 & 0xFF) * (c3 & 0xFF) * (c4 & 0xFF) * (c5 & 0xFF);
        q = Global.findit(q);

        return (Global.values[q]);
    }

    public short eval_5hand(int[] hand)
    {
        return (eval_5cards(hand[0], hand[1], hand[2], hand[3], hand[4]));
    }

    // This is a non-optimized method of determining the
    // best five-card hand possible out of seven cards.
    // I am working on a faster algorithm.
    //
    public short eval_7hand()
    {
        short i, j, q, best = 9999;
        int[] subhand = new int[5];

	    for ( i = 0; i < 21; i++ )
	    {
		    for ( j = 0; j < 5; j++ )
			    subhand[j] = hand[ Global.perm7[i,j] ];
		    q = eval_5hand( subhand );
            if (q < best)
            {
                best = q;
            }
	    }
        return best;
    }

    public string GetHandValue()
    {
        return "FIX LATER";
    }

}
