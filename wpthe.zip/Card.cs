public class Card
{
    private int rank;
    private int suit;

    public Card()
    {
        rank = -1;
        suit = -1;
    }

    // Converts an integer from 0-51 into a card.
    public Card(int newCardID)
    {
        rank = newCardID / 4;
        suit = newCardID % 4;
    }

    // Converts two integers (0-12) and (0-3) into a card.
    public Card(int newRank, int newSuit)
    {
        rank = newRank;
        suit = newSuit;
    }

    public Card( string newRank )
    {
        suit = -1;
        SetFromStr(newRank);
    }

    public string Name()
    {
        return( Rank() + "" + Suit().ToString().ToLower() );
    }

    public void SetFromStr(string newRank)
    {
        if (newRank == "")
        {
            rank = -1;
            return;
        }
        rank = (10 * (int)((char)newRank[0] - '0')) + (int)((char)newRank[1] - '0') + 0;
    }

    public int BJValue()
    {
        switch (rank)
        {
            case 12: return 11;
            case 11: return 10;
            case 10: return 10;
            case 9:  return 10;
            default: return rank + 2;
        }
    }

    public static int BJValue(int newCardID)
    {
        int i = Global.RANK(newCardID);
        if (i < 9)
        {
            return (i + 2);
        }
        if (i < 12)
        {
            return 10;
        }
        return 11;
    }

    public string FileName()
    {
        return "cards\\" + Rank() + Suit() + ".jpg";
    }

    public char Rank()
    {
        switch (rank)
        {
            case 12: return 'A';
            case 11: return 'K';
            case 10: return 'Q';
            case 9: return 'J';
            case 8: return 'T';
            default: return( (char)( rank + 2 + '0' ));
        }
    }

    public string RankNameSingular()
    {
        switch (rank)
        {
            case 12: return "Ace";
            case 11: return "King";
            case 10: return "Queen";
            case 9: return "Jack";
            case 8: return "Ten";
            case 7: return "Nine";
            case 6: return "Eight";
            case 5: return "Seven";
            case 4: return "Six";
            case 3: return "Five";
            case 2: return "Four";
            case 1: return "Trey";
            case 0: return "Deuce";
        }
        return "???";
    }

    public string RankNamePlural()
    {
        switch (rank)
        {
            case 12: return "Aces";
            case 11: return "Kings";
            case 10: return "Queens";
            case 9: return "Jacks";
            case 8: return "Tens";
            case 7: return "Nines";
            case 6: return "Eights";
            case 5: return "Sevens";
            case 4: return "Sixes";
            case 3: return "Fives";
            case 2: return "Fours";
            case 1: return "Treys";
            case 0: return "Deuces";
        }
        return "???";
    }

    public char Suit()
    {
        switch (suit)
        {
            case 3: return 's';
            case 2: return 'h';
            case 1: return 'd';
            case 0: return 'c';
        }
        return '?';
    }
}
