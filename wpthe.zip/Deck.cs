using System;

public class Deck
{
    Random random;
    int[] deck;
    int cardsLeft;

    public int CardsLeft
    {
        get
        {
            return -1; // cardsLeft;
        }
    }

    public Deck()
    {
        random = new Random();
        deck = new int[52];
        cardsLeft = 52;
        int s, r, n = 0, suit = 0x8000;
        for (s = 0; s < 4; s++, suit >>= 1)
            for (r = 0; r < 13; r++, n++)
                deck[n] = Global.primes[r] | (r << 8) | suit | (1 << (16 + r));
    }

    public void Reset()
    {
        cardsLeft = 52;
    }
    
    public void Shuffle()
    {
        int iTmp;
        int iNewSpot;

        for (int i = 0; i < cardsLeft - 1; i++)
        {
            iNewSpot = i + random.Next(cardsLeft - i);
            iTmp = deck[i];
            deck[i] = deck[iNewSpot];
            deck[iNewSpot] = iTmp;
        }
    }

    public int Pop()
    {
        if (cardsLeft > 0)
        {
            cardsLeft--;
            return deck[cardsLeft];
        }
        return -1;
    }

    public int find_card(int iRank, int iSuit)
    {
        int i, c;

        for (i = 0; i < 52; i++)
        {
            c = deck[i];
            if (((c & iSuit) > 0) && (Global.RANK(c) == iRank))
                return (i);
        }
        return (-1);
    }

    public void RemoveCard(int iRank, int iSuit)
    {
        int i = find_card(iRank, iSuit);
        deck[i] = deck[cardsLeft-1];
        cardsLeft--;
    }

}
