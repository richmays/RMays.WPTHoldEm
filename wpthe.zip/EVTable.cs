using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WPTHoldem2
{
    public partial class EVTable : Form
    {
        string NEWLINE = System.Environment.NewLine + "";
        int iLeftMargin = 11;
        int iTopMargin = 48;

        int iWidthOffset = 13;
        int iHeightOffset = 12;

        int iLastMouseX;
        int iLastMouseY;

        Graphics g;
        long iHands;
        int[,] arrTotal;
        int[,] arrRaiseWin;
        int[,] arrAllInWin;

        public EVTable()
        {
            InitializeComponent();
            lblStatus.Text = "";
            lblStatus2.Text = "";
            lblStatus3.Text = "";
            iHands = 0;
            iLastMouseX = -1;
            iLastMouseY = -1;
            arrTotal = new int[13,13];
            arrRaiseWin = new int[13, 13];
            arrAllInWin = new int[13, 13];

            for (int i = 0; i < 13; i++)
            {
                for (int j = 0; j < 13; j++)
                {
                    arrTotal[i, j] = 0;
                    arrRaiseWin[i, j] = 0;
                    arrAllInWin[i, j] = 0;
                }
            }
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);
            g = e.Graphics;

            Image imgGrid = Image.FromFile("cards/grid.gif");
            g.DrawImage(imgGrid, iLeftMargin, iTopMargin);

            string[,] sStringEV = new string[13, 13];
            int iRaiseEV;
            int iAllInEV;
            int iFoldEV;
            for (int i = 0; i < 13; i++)
            {
                for (int j = 0; j < 13; j++)
                {
                    if (arrTotal[i, j] == 0)
                    {
                        sStringEV[i, j] = "empty";
                    }
                    else
                    {
                        iRaiseEV = arrRaiseWin[i, j];
                        iAllInEV = arrAllInWin[i, j];
                        iFoldEV = arrTotal[i, j] * -1;
                        if ((iRaiseEV > iFoldEV) && (iRaiseEV > iAllInEV))
                        {
                            sStringEV[i, j] = "raise";
                        }
                        else if(( iFoldEV > iRaiseEV ) && ( iFoldEV > iAllInEV ))
                        {
                            sStringEV[i, j] = "fold";
                        }
                        else if ((iAllInEV > iRaiseEV) && (iAllInEV > iFoldEV))
                        {
                            sStringEV[i, j] = "allin";
                        }
                        else if ((iFoldEV == iRaiseEV) && (iFoldEV == iAllInEV))
                        {
                            sStringEV[i, j] = "foldraiseallin";
                        }
                        else if (iRaiseEV == iAllInEV)
                        {
                            sStringEV[i, j] = "raiseallin";
                        }
                        else if (iFoldEV == iRaiseEV)
                        {
                            sStringEV[i, j] = "foldraise";
                        }
                        else if (iFoldEV == iAllInEV)
                        {
                            sStringEV[i, j] = "foldallin";
                        }
                    }
                }
            }
            for (int i = 0; i < 13; i++)
            {
                for (int j = 0; j < 13; j++)
                {
                    PaintCard(sStringEV[i, j], i, j);
                }

            }
        }

        private void PaintCard(string sActionType, int iCard1, int iCard2)
        {
            Image imgSpot = Image.FromFile( "cards/" + sActionType + ".gif" );
            g.DrawImage(imgSpot, iLeftMargin + iWidthOffset + ((12 - iCard1) * 26), iTopMargin + iHeightOffset + ((12 - iCard2) * 17));
        }

        /*
        private void DoEveryCombination2()
        {
            int p1, p2;
            int d1, d2;
            int c1, c2, c3, c4, c5;
            Hand hPlayerHand = new Hand();
            Hand hDealerHand = new Hand();
            int[] iComm = new int[5];
            int iCardX, iCardY;
            int iBJCount;
            int iResult;
            bool bIsPair;
            for (p1 = 0; p1 < 51; p1++)
            {
                hPlayerHand.AddCard(p1);
                for (p2 = p1 + 1; p2 < 52; p2++)
                {
                    hPlayerHand.AddCard(p2);
                    if (p1 % 4 == p2 % 4) // if they're suited ...
                    {
                        //                lblStatus.Text += "s";
                        iCardX = p2 / 4;
                        iCardY = p1 / 4;
                    }
                    else
                    {
                        iCardX = p1 / 4;
                        iCardY = p2 / 4;
                    }
                    for (d1 = 0; d1 < 51; d1++)
                    {
                        if(( d1 != p1) && ( d1 != p2 ))
                        {
                            hDealerHand.AddCard(d1);
                            for (d2 = d1 + 1; d2 < 52; d2++)
                            {
                                if ((d2 != p1) && (d2 != p2))
                                {
                                    hDealerHand.AddCard(d2);
                                    iBJCount = Card.BJValue(d1) + Card.BJValue(d2);
                                    bIsPair = (d1 / 4 == d2 / 4);
                                    if ((iBJCount < 13) && !bIsPair)
                                    {
                                        // Folding; player wins.
                                        arrTotal[iCardX, iCardY] += 1712304;
                                        iHands += 1712304;
                                        arrRaiseWin[iCardX, iCardY] += 1712304;
                                        arrAllInWin[iCardX, iCardY] += 1712304;
                                    }
                                    else
                                    {
                                        for (c1 = 0; c1 < 48; c1++)
                                        {
                                            if ((c1 != p1) && (c1 != p2) && (c1 != d1) && (c1 != d2))
                                            {
                                                iComm[0] = c1;
                                                for (c2 = c1 + 1; c2 < 49; c2++)
                                                {
                                                    if ((c2 != p1) && (c2 != p2) && (c2 != d1) && (c2 != d2))
                                                    {
                                                        iComm[1] = c2;
                                                        for (c3 = c2 + 1; c3 < 50; c3++)
                                                        {
                                                            if ((c3 != p1) && (c3 != p2) && (c3 != d1) && (c3 != d2))
                                                            {
                                                                iComm[2] = c3;
                                                                for (c4 = c3 + 1; c4 < 51; c4++)
                                                                {
                                                                    if ((c4 != p1) && (c4 != p2) && (c4 != d1) && (c4 != d2))
                                                                    {
                                                                        iComm[3] = c4;
                                                                        for (c5 = c4 + 1; c5 < 52; c5++)
                                                                        {
                                                                            if ((c5 != p1) && (c5 != p2) && (c5 != d1) && (c5 != d2))
                                                                            {
                                                                                iComm[4] = c5;
                                                                                for (int i = 0; i < 5; i++)
                                                                                {
                                                                                    hPlayerHand.AddCard(iComm[i]);
                                                                                    hDealerHand.AddCard(iComm[i]);
                                                                                }

                                                                                arrTotal[iCardX, iCardY]++;
                                                                                iHands++;

                                                                                    // Calls a raise.
                                                                                    iResult = string.Compare(hPlayerHand.GetHandValue(), hDealerHand.GetHandValue());
                                                                                    if (iResult == -1) // Player lost.
                                                                                    {
                                                                                        arrRaiseWin[iCardX, iCardY] -= 6;
                                                                                    }
                                                                                    else if (iResult == 1) // Player won.
                                                                                    {
                                                                                        arrRaiseWin[iCardX, iCardY] += 6;
                                                                                    }
                                                                                if ((iBJCount >= 17) || bIsPair)
                                                                                {
                                                                                    // Calls an all-in.

                                                                                    // iResult was already set in the previous block.
                                                                                    //iResult = string.Compare(hPlayerHand.GetHandValue(), hDealerHand.GetHandValue());
                                                                                    if (iResult == -1) // Player lost.
                                                                                    {
                                                                                        arrAllInWin[iCardX, iCardY] -= 11;
                                                                                    }
                                                                                    else if (iResult == 1) // Player won.
                                                                                    {
                                                                                        arrAllInWin[iCardX, iCardY] += 11;
                                                                                    }
                                                                                }
                                                                                else
                                                                                {
                                                                                    arrAllInWin[iCardX, iCardY]++;
                                                                                }

                                                                                for (int i = 0; i < 5; i++)
                                                                                {
                                                                                    hPlayerHand.RemoveCard(iComm[i]);
                                                                                    hDealerHand.RemoveCard(iComm[i]);
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    hDealerHand.RemoveCard(d2);
                                }
                            }
                            hDealerHand.RemoveCard(d1);
                        }
                    }
                    hPlayerHand.RemoveCard(p2);
                }
                hPlayerHand.RemoveCard(p1);
            }
        }
*/
        /*
        private void DoEveryCombination()
        {
            int[] iCards = new int[9];
            int currCard;
            bool good = true;
            bool moved;
            int iTmp;
            // Reset the 9 cards.
            for (int i = 0; i < 9; i++)
            {
                iCards[i] = i;
            }
            // Now, do combinations.
            while (good)
            {
                if (IsComboGood(iCards))
                {
                    DoThisCombination(iCards);
                    if (iCards[7] > 49)
                    {
                        int p = 999;
                    }
                }
                // Find the next combo.
                currCard = 8;
                moved = false;
                while ((!moved) && (currCard >= 0)) // ## TODO
                {
                    if (iCards[currCard] < 51)
                    {
                        iCards[currCard]++;
                        moved = true;
                    }
                    else
                    {
                        iCards[currCard] = -1; // changed in later code
                        currCard--;
                    }
                }
                if (currCard == -1)
                {
                    good = false;
                }
                else
                {
                    if (currCard >= 3)
                    {
                        for (iTmp = currCard + 1; iTmp < 9; iTmp++)
                        {
                            iCards[ iTmp ] = GetNextUnusedInt(iCards, iCards[ iTmp - 1 ] + 1);
                        }
                    }
                    else if (currCard == 2)
                    {
                        iCards[ 3 ] = GetNextUnusedInt( iCards, iCards[ 2 ] + 1);
                    }
                    else if (currCard == 0)
                    {
                        iCards[ 1 ] = GetNextUnusedInt(iCards, iCards[ 0 ] + 1);
                    }
                }
            }
        }
        */

        private bool IsComboGood( int[] iCards )
        {
            for (int i = 0; i < 8; i++)
            {
                for (int j = i+1; j < 9; j++)
                {
                    if (iCards[i] == iCards[j])
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        /*
        private void DoThisCombination( int[] iCards )
        {
            Hand hPlayerHand = new Hand();
            Hand hDealerHand = new Hand();
            int iCardX, iCardY;
            int iBJCount;
            int iResult;

            hPlayerHand.AddCard(iCards[0]);
            hPlayerHand.AddCard(iCards[1]);
            hDealerHand.AddCard(iCards[2]);
            hDealerHand.AddCard(iCards[3]);
            for (int i = 4; i < 9; i++)
            {
                hPlayerHand.AddCard(iCards[i]);
                hDealerHand.AddCard(iCards[i]);
            }

            if (iCards[0] % 4 == iCards[1] % 4) // if they're suited ...
            {
                //                lblStatus.Text += "s";
                iCardX = iCards[1] / 4;
                iCardY = iCards[0] / 4;
            }
            else
            {
                iCardX = iCards[0] / 4;
                iCardY = iCards[1] / 4;
            }
            arrTotal[iCardX, iCardY]++;
            iHands++;
            // See who wins.
            iBJCount = Card.BJValue(iCards[2]) + Card.BJValue(iCards[3]);
            if ((iBJCount >= 13) || (iCards[2] / 4 == iCards[3] / 4))
            {
                // Calls a raise.
                iResult = string.Compare(hPlayerHand.GetHandValue(), hDealerHand.GetHandValue());
                if (iResult == -1) // Player lost.
                {
                    arrRaiseWin[iCardX, iCardY] -= 6;
                }
                else if (iResult == 1) // Player won.
                {
                    arrRaiseWin[iCardX, iCardY] += 6;
                }
            }
            else
            {
                arrRaiseWin[iCardX, iCardY]++;
            }
            if ((iBJCount >= 17) || (iCards[2] / 4 == iCards[3] / 4))
            {
                // Calls an all-in.
                iResult = string.Compare(hPlayerHand.GetHandValue(), hDealerHand.GetHandValue());
                if (iResult == -1) // Player lost.
                {
                    arrAllInWin[iCardX, iCardY] -= 11;
                }
                else if (iResult == 1) // Player won.
                {
                    arrAllInWin[iCardX, iCardY] += 11;
                }
            }
            else
            {
                arrAllInWin[iCardX, iCardY]++;
            }

        }
        */

        /*
        private int GetNextUnusedInt(int[] iCards, int iMin)
        {
            int i = iMin;
            while( true )
            {
                if (iCards[0] != i && iCards[1] != i && iCards[2] != i && iCards[3] != i && iCards[4] != i && iCards[5] != i && iCards[6] != i && iCards[7] != i && iCards[8] != i)
                {
                    return i;
                }
                i++;
            }
        }
        */

        private void RunOneComboGivenPlayerHand(Deck d, int iPlayerCard1, int iPlayerCard2)
        {
            Hand hPlayerHand = new Hand();
            Hand hDealerHand = new Hand();
            int iDealerCard1, iDealerCard2;
            int iCardX, iCardY;
            int iBJCount;
            int[] iCommCard = new int[5];
            int iResult;
            bool bIsPair;

            iDealerCard1 = d.Pop();
            iDealerCard2 = d.Pop();
            for (int i = 0; i < 5; i++)
            {
                iCommCard[i] = d.Pop();
                hPlayerHand.AddCard(iCommCard[i]);
                hDealerHand.AddCard(iCommCard[i]);
            }
            hPlayerHand.AddCard(iPlayerCard1);
            hPlayerHand.AddCard(iPlayerCard2);
            hDealerHand.AddCard(iDealerCard1);
            hDealerHand.AddCard(iDealerCard2);

            //            lblStatus.Text = (new Card(iPlayerCard1)).Rank() + "" + (new Card(iPlayerCard2)).Rank();
            if (iPlayerCard1 % 4 == iPlayerCard2 % 4) // if they're suited ...
            {
                //                lblStatus.Text += "s";
                iCardX = iPlayerCard2 / 4;
                iCardY = iPlayerCard1 / 4;
            }
            else
            {
                iCardX = iPlayerCard1 / 4;
                iCardY = iPlayerCard2 / 4;
            }
            arrTotal[iCardX, iCardY]++;
            iHands++;
            // See who wins.
            iBJCount = Card.BJValue(iDealerCard1) + Card.BJValue(iDealerCard2);
            bIsPair = (iDealerCard1 / 4 == iDealerCard2 / 4);
            if ((iBJCount < 13) && !bIsPair)
            {
                arrRaiseWin[iCardX, iCardY]++;
                arrAllInWin[iCardX, iCardY]++;
                return;
            }

            // Calls a raise.
            iResult = string.Compare(hPlayerHand.GetHandValue(), hDealerHand.GetHandValue());
            if (iResult == -1) // Player lost.
            {
                arrRaiseWin[iCardX, iCardY] -= 6;
            }
            else if (iResult == 1) // Player won.
            {
                arrRaiseWin[iCardX, iCardY] += 6;
            }

            if ((iBJCount >= 17) || bIsPair) // 17
            {
                // Calls an all-in.
                // No need to run this line; we know what 'iResult' is already.
                //iResult = string.Compare(hPlayerHand.GetHandValue(), hDealerHand.GetHandValue());
                if (iResult == -1) // Player lost.
                {
                    arrAllInWin[iCardX, iCardY] -= 11;
                }
                else if (iResult == 1) // Player won.
                {
                    arrAllInWin[iCardX, iCardY] += 11;
                }
            }
            else
            {
                arrAllInWin[iCardX, iCardY]++;
            }
        }

        private void RunOneCombo( Deck d )
        {
            int iPlayerCard1, iPlayerCard2;
            int iDealerCard1, iDealerCard2;
            Hand hPlayerHand = new Hand();
            Hand hDealerHand = new Hand();
            int iCardX, iCardY;
            int iBJCount;
            int[] iCommCard = new int[5];
            bool bIsPair;
            int iPlayerHandValue;
            int iDealerHandValue;

            iPlayerCard1 = d.Pop();
            iPlayerCard2 = d.Pop();
            iDealerCard1 = d.Pop();
            iDealerCard2 = d.Pop();

            for (int i = 0; i < 5; i++)
            {
                iCommCard[i] = d.Pop();
                hPlayerHand.AddCard(iCommCard[i]);
                hDealerHand.AddCard(iCommCard[i]);
            }
            hPlayerHand.AddCard(iPlayerCard1);
            hPlayerHand.AddCard(iPlayerCard2);
            hDealerHand.AddCard(iDealerCard1);
            hDealerHand.AddCard(iDealerCard2);

            if (iPlayerCard1 > iPlayerCard2)
            {
                int iCardTmp = iPlayerCard1;
                iPlayerCard1 = iPlayerCard2;
                iPlayerCard2 = iCardTmp;
            }

            if ((iPlayerCard1 & iPlayerCard2 & 0xF000) > 0)
            {
                iCardX = Global.RANK(iPlayerCard1);
                iCardY = Global.RANK(iPlayerCard2);
            }
            else
            {
                iCardX = Global.RANK(iPlayerCard2);
                iCardY = Global.RANK(iPlayerCard1);
            }
            
            arrTotal[iCardX, iCardY]++;
            iHands++;
            // See who wins.
            iBJCount = Card.BJValue(iDealerCard1) + Card.BJValue(iDealerCard2);
            bIsPair = ((iDealerCard1 & iDealerCard2 & 0xFFFF0000) > 1);
            if ((iBJCount < 13) && !bIsPair)
            {
                arrRaiseWin[iCardX, iCardY]++;
                arrAllInWin[iCardX, iCardY]++;
                return;
            }

            // Calls a raise.

            iPlayerHandValue = hPlayerHand.eval_7hand();
            iDealerHandValue = hDealerHand.eval_7hand();
            if (iPlayerHandValue > iDealerHandValue) // Player lost.
            {
                arrRaiseWin[iCardX, iCardY] -= 6;
            }
            else if (iPlayerHandValue < iDealerHandValue) // Player won.
            {
                arrRaiseWin[iCardX, iCardY] += 6;
            }

            if ((iBJCount >= 17) || bIsPair) // 17
            {
                // Calls an all-in.
                // No need to run this line; we know what 'iResult' is already.
                //iResult = string.Compare(hPlayerHand.GetHandValue(), hDealerHand.GetHandValue());
                if (iPlayerHandValue > iDealerHandValue) // Player lost.
                {
                    arrAllInWin[iCardX, iCardY] -= 11;
                }
                else if (iPlayerHandValue < iDealerHandValue) // Player won.
                {
                    arrAllInWin[iCardX, iCardY] += 11;
                }
            }
            else
            {
                arrAllInWin[iCardX, iCardY]++;
            }
        }

        private void EVTable_MouseMove(object sender, MouseEventArgs e)
        {
            int iCard1, iCard2;
            iCard1 = 12 - ((e.X - iWidthOffset - iLeftMargin) / 26);
            iCard2 = 12 - ((e.Y - iHeightOffset - iTopMargin) / 17);
            if ((iCard1 <= 12) && (iCard2 <= 12))
            {
                if ((iCard1 >= 0) && (iCard2 >= 0))
                {
                    if ((iCard1 != iLastMouseX) || (iCard2 != iLastMouseY))
                    {
                        HandleMouseMove(iCard1, iCard2);
                    }
                }
            }
        }

        private void EVTable_MouseClick(object sender, MouseEventArgs e)
        {
            HandleMouseClick(10000);
        }

        private void EVTable_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            HandleMouseClick(90000);
        }

        private void HandleMouseMove( int iCard1, int iCard2 )
        {
            iLastMouseX = iCard1;
            iLastMouseY = iCard2;
            string strStatus = "";
            string strStatus2 = "";
            string strStatus3 = "";
            string strHandShort;
//          strStatus += "Hover: (" + iCard1 + "," + iCard2 + ")" + System.Environment.NewLine;
//          Find out which hand it is.
            if (iCard1 > iCard2)
            {
                strHandShort = (new Card(iCard1 * 4)).Rank() + "" + (new Card(iCard2 * 4)).Rank() + "o";
            }
            else
            {
                strHandShort = (new Card(iCard2 * 4)).Rank() + "" + (new Card(iCard1 * 4)).Rank();
                if (iCard1 != iCard2)
                {
                    strHandShort += "s";
                }
            }
            strStatus = "";
            strStatus += "Hand:" + NEWLINE;
            strStatus += "Times Seen:" + NEWLINE;
            strStatus += "Fold Net $:" + NEWLINE;
            strStatus += "Raise Net $:" + NEWLINE;
            strStatus += "All In Net $:" + NEWLINE;

            strStatus2 = "";
            strStatus2 += strHandShort + NEWLINE;
            strStatus2 += arrTotal[iCard1, iCard2] + NEWLINE;
            strStatus2 += (-1 * arrTotal[iCard1, iCard2]) + NEWLINE;
            strStatus2 += arrRaiseWin[iCard1, iCard2] + NEWLINE;
            strStatus2 += arrAllInWin[iCard1, iCard2] + NEWLINE;

            strStatus3 = "";
            strStatus3 += "Expected Value" + NEWLINE;
            strStatus3 += "" + NEWLINE;
            strStatus3 += -1.0d + NEWLINE;
            if (arrTotal[iCard1, iCard2] != 0)
            {
                strStatus3 += ((arrRaiseWin[iCard1, iCard2] * 1.0d) / (arrTotal[iCard1, iCard2] * 1.0d)) + NEWLINE;
                strStatus3 += ((arrAllInWin[iCard1, iCard2] * 1.0d) / (arrTotal[iCard1, iCard2] * 1.0d)) + NEWLINE;
            }

            lblStatus.Text = strStatus;
            lblStatus2.Text = strStatus2;
            lblStatus3.Text = strStatus3;
        }

        private void HandleMouseClick( int iTimes )
        {
            if ((iLastMouseX < 0) || (iLastMouseY < 0))
            {
                return;
            }
            DisableButtons();

            int iPlayerCard1;
            int iPlayerCard2;
            if (iLastMouseX < iLastMouseY)
            {
                iPlayerCard1 = iLastMouseX * 4;
                iPlayerCard2 = iLastMouseY * 4;
            }
            else if (iLastMouseX > iLastMouseY)
            {
                iPlayerCard1 = iLastMouseY * 4;
                iPlayerCard2 = (iLastMouseX * 4) + 1;
            }
            else
            {
                iPlayerCard1 = iLastMouseX * 4;
                iPlayerCard2 = iPlayerCard1 + 1;
            }

            Deck d = new Deck();
            if (iPlayerCard2 > iPlayerCard1)
            {
                int iTmp = iPlayerCard1;
                iPlayerCard1 = iPlayerCard2;
                iPlayerCard2 = iTmp;
            }
            for (int i = 0; i < iTimes; i++)
            {
                d.Reset();
//                d.RemoveCard(iPlayerCard1);
//                d.RemoveCard(iPlayerCard2);
                d.Shuffle();
                RunOneComboGivenPlayerHand(d, iPlayerCard1, iPlayerCard2);
            }
            lblTotalHands.Text = "Total Hands: " + iHands;
            HandleMouseMove( iLastMouseX, iLastMouseY );
            Invalidate();

            EnableButtons();
        }

        private void DisableButtons()
        {
            btnStart1.Enabled = false;
            btnStart2.Enabled = false;
            btnStart3.Enabled = false;
            btnStart4.Enabled = false;
            btnStart5.Enabled = false;
            btnStart6.Enabled = false;
            btnStart7.Enabled = false;
            btnStart8.Enabled = false;
            btnAll.Enabled = false;
        }

        private void EnableButtons()
        {
            btnStart1.Enabled = true;
            btnStart2.Enabled = true;
            btnStart3.Enabled = true;
            btnStart4.Enabled = true;
            btnStart5.Enabled = true;
            btnStart6.Enabled = true;
            btnStart7.Enabled = true;
            btnStart8.Enabled = true;
            btnAll.Enabled = true;
        }

        private void RunCombo(int iTimes)
        {
            DateTime dt = new DateTime();
            TimeSpan ts = new TimeSpan();

            dt = DateTime.Now;

            Deck d = new Deck();
            for (int i = 0; i < iTimes; i++)
            {
                d.Reset();
                d.Shuffle();
                RunOneCombo(d);
            }
            lblTotalHands.Text = "Total Hands: " + iHands;

            ts = DateTime.Now - dt;
            lblStatus3.Text = " Time: " + ts.TotalSeconds + " seconds";
            
            Invalidate();
        }
        #region Buttons
        private void btnStart1_Click(object sender, EventArgs e)
        {
            DisableButtons();
            RunCombo(1);
            EnableButtons();
        }

        private void btnStart2_Click(object sender, EventArgs e)
        {
            DisableButtons();
            RunCombo(10);
            EnableButtons();
        }

        private void btnStart3_Click(object sender, EventArgs e)
        {
            DisableButtons();
            RunCombo(100);
            EnableButtons();
        }

        private void btnStart4_Click(object sender, EventArgs e)
        {
            DisableButtons();
            RunCombo(1000);
            EnableButtons();

        }

        private void btnStart5_Click(object sender, EventArgs e)
        {
            DisableButtons();
            RunCombo(10000);
            EnableButtons();

        }

        private void btnStart6_Click(object sender, EventArgs e)
        {
            DisableButtons();
            RunCombo(100000);
            EnableButtons();

        }

        private void btnStart7_Click(object sender, EventArgs e)
        {
            DisableButtons();
            RunCombo(1000000);
            EnableButtons();

        }

        private void btnStart8_Click(object sender, EventArgs e)
        {
            DisableButtons();
            RunCombo(10000000);
            EnableButtons();
        }
        #endregion

        private void btnAll_Click(object sender, EventArgs e)
        {
            DisableButtons();
//            DoEveryCombination2();
            EnableButtons();
        }

    }
}
